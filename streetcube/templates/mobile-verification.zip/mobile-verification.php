<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Mobile Verification</h1>
	</div>
</section>
<section class="pt-5 pb-5 bg-silver">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-body text-center pt-5 pb-5">
						<h5>Do you mind if we verify, and send you a text?</h5>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input">
							<label class="custom-control-label" for="customRadioInline1">Yes</label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
							<label class="custom-control-label" for="customRadioInline2">No</label>
						</div>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-8">
								
								<div class="alert alert-danger mt-3">
									Hi, I think we didn’t get your number correctly, please call support on 020 3514 2233 thanks !
								</div>
							</div>
							<div class="col-md-2"></div>
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-6"></div>
							<div class="col-6 text-right">
								<a href="verified-msg.php" class="btn btn-danger">Next</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php include('include/footer.php'); ?>