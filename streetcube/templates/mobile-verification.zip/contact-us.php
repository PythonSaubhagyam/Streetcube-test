<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Contact us</h1>
	</div>
</section>
<section class="bg-silver pt-5 pb-5">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="bg-white p-3">
					<h6 class="mb-4">LANDMARK</h6>
					<div class="row">
						<div class="col-md-4">
							<p class="m-0">27 Old Gloucester Street</p>
							<p class="m-0">London WC1N 3AX</p>
						</div>
						<div class="col-md-4">
							<p><img width="15" src="images/icons/call.svg"> 020 3514 2233</p>
							<p><img width="15" src="images/icons/mail.svg"> info@streetcube.org</p>
						</div>
						<div class="col-md-4 text-center">
							<img width="75" src="images/icons/location.svg">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row mt-4">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="bg-white p-4">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Enter Full Name" name="">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Enter Email" name="">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Enter Subject" name="">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<textarea class="form-control" rows="5" placeholder="Enter Message"></textarea>
							</div>
						</div>
						<div class="col-md-12 text-right">
							<button class="btn btn-danger">Send</button>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php include('include/footer.php'); ?>