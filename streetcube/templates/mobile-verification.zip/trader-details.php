<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Trader Details</h1>
	</div>
</section>
<section class="pt-5 pb-5 bg-silver">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-body text-center pt-5 pb-5">
						<h5>Can we get the rest of your details please..?</h5>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input">
							<label class="custom-control-label" for="customRadioInline1">Yes</label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
							<label class="custom-control-label" for="customRadioInline2">No</label>
						</div>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-8">
								
								<div class="form-group">
									<div class="text-left">
										<label>Address</label>
									</div>
									<input type="text" class="form-control" placeholder="Enter Address" name="">
								</div>
								<div class="form-group">
									<div class="text-left">
										<label>Phone No.</label>
									</div>
									<input type="text" class="form-control" placeholder="Enter Phone No." name="">
								</div>
								<div class="form-group">
									<div class="text-left">
										<label>Address</label>
									</div>
									<input type="text" class="form-control" placeholder="Enter Email" name="">
								</div>
								<div class="form-group">
									<div class="text-left">
										<label>Company Name</label>
									</div>
									<input type="text" class="form-control" placeholder="Enter Company Name" name="">
								</div>
								<div class="form-group">
									<div class="text-left">
										<label>Brand Name</label>
									</div>
									<input type="text" class="form-control" placeholder="Enter Brand Name" name="">
								</div>
								<div class="form-group">
									<div class="text-left">
										<label>Description of services and products</label>
									</div>
									<textarea class="form-control" rows="6" placeholder="Enter Description"></textarea>
								</div>
								<div class="form-group">
									<div class="text-left">
										<label>Story - how did you start up?</label>
									</div>
									<textarea class="form-control" rows="6" placeholder="Enter Story"></textarea>
								</div>
							</div>
							<div class="col-md-2"></div>
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-6"></div>
							<div class="col-6 text-right">
								<a href="upload-documents.php" class="btn btn-danger">Next</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php include('include/footer.php'); ?>