<?php include('include/header.php'); ?>
<section class="page-bg">
    <div class="container text-center">
        <img width="150" src="images/logo/logo.png">
        <h1 class="text-white mt-5">Select your slot and book</h1>
    </div>
</section>
<section>
	<div class="container mt-4 mb-4">
		<img class="img-fluid" src="images/banner/map.svg">
		


	</div>
</section>
<section>
	<div class="container mb-4">
		<h3 class="mt-5 mb-5 text-center">Select your <spna class="text-danger">slot</spna></h3>
		<div class="row">
			<div class="col-md-2 col-6">
				<a href="booking.php" class="btn btn-block mb-3 f-btn f1">1 F</a>
				<a href="booking.php" class="btn btn-block mb-3 f-btn f1">1 S</a>
				<a href="booking.php" class="btn btn-block mb-3 f-btn f1">1 S</a>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f2">2 F</button>
				<button class="btn btn-block mb-3 f-btn f2">2 S</button>
				<button class="btn btn-block mb-3 f-btn f2">2 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f3">3 F</button>
				<button class="btn btn-block mb-3 f-btn f3">3 S</button>
				<button class="btn btn-block mb-3 f-btn f3">3 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f4">4 F</button>
				<button class="btn btn-block mb-3 f-btn f4">4 S</button>
				<button class="btn btn-block mb-3 f-btn f4">4 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f5">5 F</button>
				<button class="btn btn-block mb-3 f-btn f5">5 S</button>
				<button class="btn btn-block mb-3 f-btn f5">5 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f6">6 F</button>
				<button class="btn btn-block mb-3 f-btn f6">6 S</button>
				<button class="btn btn-block mb-3 f-btn f6">6 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f7">7 F</button>
				<button class="btn btn-block mb-3 f-btn f7">7 S</button>
				<button class="btn btn-block mb-3 f-btn f7">7 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f8">8 F</button>
				<button class="btn btn-block mb-3 f-btn f8">8 S</button>
				<button class="btn btn-block mb-3 f-btn f8">8 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f9">9 F</button>
				<button class="btn btn-block mb-3 f-btn f9">9 S</button>
				<button class="btn btn-block mb-3 f-btn f9">9 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f10">10 F</button>
				<button class="btn btn-block mb-3 f-btn f10">10 S</button>
				<button class="btn btn-block mb-3 f-btn f10">10 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f11">11 F</button>
				<button class="btn btn-block mb-3 f-btn f11">11 S</button>
				<button class="btn btn-block mb-3 f-btn f11">11 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f12">12 F</button>
				<button class="btn btn-block mb-3 f-btn f12">12 S</button>
				<button class="btn btn-block mb-3 f-btn f12">12 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f13">13 F</button>
				<button class="btn btn-block mb-3 f-btn f13">13 S</button>
				<button class="btn btn-block mb-3 f-btn f13">13 S</button>
			</div>
			<div class="col-md-2 col-6">
				<button class="btn btn-block mb-3 f-btn f14">14 F</button>
				<button class="btn btn-block mb-3 f-btn f14">14 S</button>
				<button class="btn btn-block mb-3 f-btn f14">14 S</button>
			</div>
		</div>
	</div>
</section>

<?php include('include/footer.php'); ?>