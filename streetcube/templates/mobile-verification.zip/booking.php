<?php include('include/header.php'); ?>
<link id="bsdp-css" href="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/css/bootstrap-datepicker3.min.css" rel="stylesheet">
<script src="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/js/bootstrap-datepicker.min.js"></script>

<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Select your slot and pay.</h1>
	</div>
</section>

<section class="bg-silver pb-5 pt-5">
	<div class="container bg-white pt-4 pb-4">
		<div class="row">			
			<div class="col-md-6 text-center mb-4">
				<h5>Your market slot (14 F)</h5>
				<img class="border p-3 img-fluid" src="images/banner/short_map.jpg">
			</div>
			<div class="col-md-6 mb-4">
				<h5 class="text-center mb-3">Select date</h5>
				<div id="cal" class="datepicker_full_width"></div>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<p>You have selected market slot for <b> 4, 5, 11 September</b>.</p>
				<p>And your total amount is <b>£400</b></p>
			</div>
			<div class="col-md-6 text-right">
				<a href="#" class="btn btn-danger mt-4">Proceed to pay £400</a>
			</div>
		</div>
	</div>
</section>










<script>
	$('#cal').datepicker({
    multidate: true,
    daysOfWeekDisabled: "1,2,3,4",
    // daysOfWeekHighlighted: "0,5,6",
    todayHighlight: true
});
</script>
<?php include('include/footer.php'); ?>