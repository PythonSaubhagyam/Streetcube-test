<footer class="bg-danger">
    <div class="container text-center pt-5 pb-5 text-white">
        <h3>Find us on</h3>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="d-flex mt-5">
                    <div class="flex-fill">
                        <a href="#">
                            <img height="40" data-toggle="tooltip" data-placement="top" title="Facebook" src="images/icons/facebook.svg">
                        </a>
                    </div>
                    <div class="flex-fill">
                        <a href="#">
                            <img height="40" data-toggle="tooltip" data-placement="top" title="Instagram" src="images/icons/instagram.svg">
                        </a>
                    </div>
                    <div class="flex-fill">
                        <a href="#">
                            <img height="40" data-toggle="tooltip" data-placement="top" title="Twitter" src="images/icons/twitter.svg">
                        </a>
                    </div>
                    <div class="flex-fill">
                        <a href="#">
                            <img height="40" data-toggle="tooltip" data-placement="top" title="WhatsApp" src="images/icons/whatsapp.svg">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3"></div>
        </div>
        <ul class="nav justify-content-center mt-4">
            <li class="nav-item">
                <a class="nav-link text-white" href="#">About us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Contact us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Join us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">How it works</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">FAQs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Privacy</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Tearms</a>
            </li>
        </ul>
    </div>
    <div class="bg-dark text-center pt-3 pb-3">
        <small class="text-white">© Copyright <?php echo date("Y"); ?> Company name LLC. All Rights Reserved</small>
    </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="boots/js/js.js"></script>
<script>
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
</script>
</body>
</html>