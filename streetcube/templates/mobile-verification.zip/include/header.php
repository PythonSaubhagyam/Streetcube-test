<!DOCTYPE html>
<html lang="en">
    <head>
        <title>StreetCube Market</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="boots/css/style.css">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobile_nav" aria-controls="mobile_nav" aria-expanded="false" aria-label="Toggle navigation">
                <div id="nav-icon1">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                </button>
                <div class="collapse navbar-collapse" id="mobile_nav">
                    <ul class="navbar-nav mr-auto mt-2 mt-lg-0 float-md-right">
                    </ul>
                    <ul class="navbar-nav navbar-light" id="mynav">
                        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="about-us.php">About us</a></li>
                        <li class="nav-item"><a class="nav-link" href="markets.php">Markets</a></li>
                        <li class="nav-item"><a class="nav-link" href="join-now.php">Join Now</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact-us.php">Contact us</a></li>
                    </ul>
                </div>
            </div>
        </nav>