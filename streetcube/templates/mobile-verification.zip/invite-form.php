<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Join Now</h1>
	</div>
</section>
<section class="pt-5 pb-5 bg-silver">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-body text-center pt-5 pb-5">
						<h5>That’s great</h5>
						<p>we would like to invite you to trade with us.</p>
						<p>Can we get your number</p>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input">
							<label class="custom-control-label" for="customRadioInline1">Yes</label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
							<label class="custom-control-label" for="customRadioInline2">No</label>
						</div>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-8">
								<div class="form-group mt-4 mb-4">
									<label>We can arrange a call..</label>
									<input type="text" class="form-control form-control-lg" placeholder="Enter your mobile number." name="">
								</div>
							</div>
							<div class="col-md-2"></div>
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-6"></div>
							<div class="col-6 text-right">
								<a href="mobile-verification.php" class="btn btn-danger">Next</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php include('include/footer.php'); ?>