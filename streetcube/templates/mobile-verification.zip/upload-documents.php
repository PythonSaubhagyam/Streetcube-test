<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Mobile Verification</h1>
	</div>
</section>
<section class="pt-5 pb-5 bg-silver">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-body text-center pt-5 pb-5">
						<h5>Upload document</h5>
						<br>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-8 text-left">
								<label class="mt-4">Public liability insurance</label>
								<div class="custom-file">									
									<input type="file" class="custom-file-input" id="customFile">
									<label class="custom-file-label" for="customFile">Choose file</label>
								</div>
								<label class="mt-4">Covid-19 risk assessment form</label>
								<div class="custom-file">									
									<input type="file" class="custom-file-input" id="customFile">
									<label class="custom-file-label" for="customFile">Choose file</label>
								</div>
								<label class="mt-4">Food and hygiene certificate</label>
								<div class="custom-file">									
									<input type="file" class="custom-file-input" id="customFile">
									<label class="custom-file-label" for="customFile">Choose file</label>
								</div>

							</div>
							<div class="col-md-2"></div>
						</div>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-6"></div>
							<div class="col-6 text-right">
								<a href="booking-slot.php" class="btn btn-danger">Next</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php include('include/footer.php'); ?>