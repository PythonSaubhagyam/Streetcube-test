<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Contact us</h1>
	</div>
</section>
<section class="bg-silver pt-5 pb-5">
	<div class="container bg-white">
		121
	</div>
</section>
<?php include('include/footer.php'); ?>