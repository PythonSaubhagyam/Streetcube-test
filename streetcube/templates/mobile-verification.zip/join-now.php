<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Join Now</h1>
	</div>
</section>
<section class="pt-5 pb-5 bg-silver">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-body text-center pt-5 pb-5">
						<h5>Hi, please enter your email address</h5>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-8">
								<div class="form-group mt-4 mb-4">
							<input type="text" class="form-control form-control-lg" placeholder="Enter your email" name="">
						</div>
							</div>
							<div class="col-md-2"></div>
						</div>
						<a class="a-no" href="login.php">Maybe you’re already registered?</a>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-6"></div>
							<div class="col-6 text-right">
								<a href="invite-form.php" class="btn btn-danger">Next</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php include('include/footer.php'); ?>