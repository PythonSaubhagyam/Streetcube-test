<?php include('include/header.php'); ?>
<section class="page-bg">
	<div class="container text-center">
		<img width="150" src="images/logo/logo.png">
		<h1 class="text-white mt-5">Log In</h1>
	</div>
</section>
<section class="pt-5 pb-5 bg-silver">
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-body text-center pt-5 pb-5">
						<h5>Hey, are you a trader</h5>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-8">
								<div class="form-group mt-4 mb-4">
									<input type="email" class="form-control form-control-lg" placeholder="Enter your email" name="">
								</div>
								<div class="form-group mt-4 mb-4">
									<input type="password" class="form-control form-control-lg" placeholder="Enter your password" name="">
								</div>
							</div>
							<div class="col-md-2"></div>
						</div>
						<a class="a-no" href="join-now.php">Maybe you’re not registered?</a>
					</div>
					<div class="card-footer">
						<div class="row">
							<div class="col-6"></div>
							<div class="col-6 text-right">
								<a href="#" class="btn btn-danger">Next</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</section>
<?php include('include/footer.php'); ?>